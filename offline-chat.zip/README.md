# OfflineChat (scaffold)

This is a scaffold for an offline-first secure Android chat app (Kotlin + Jetpack Compose).

## What is included
- Compose UI skeleton (chat screen, composer)
- Room database entities/DAO
- Network monitor (ConnectivityManager NetworkCallback)
- WorkManager stub for retrying queued messages
- WebSocket and WebRTC stubs
- SMS wrapper (very basic)
- Telephony fallback helper
- Encryption stub (replace with libsignal-protocol-java or libsodium)

## Next steps (recommended)
1. Integrate real encryption: libsignal-protocol-java (or maintained bindings).
2. Implement signaling server and point WebSocketClient to it.
3. Replace EncryptionManager stub with real Signal double-ratchet flows: registration, pre-keys, X3DH handshake, etc.
4. Implement SMS fragmentation/reassembly, encryption payload packaging, and user consent UI.
5. Use Encrypted Room / SQLCipher for DB encryption-at-rest.
6. Implement WebRTC flows, ICE servers, and call UI with foreground service and Telecom integration.
7. Add certificate pinning and security scanning in CI.

## How to build
1. Download or copy this project into Android Studio.
2. Open the project and let Gradle sync (install appropriate SDKs).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).

## License
Scaffold provided "as-is". Replace stub crypto before production.
