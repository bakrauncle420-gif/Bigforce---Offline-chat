rootProject.name = "offline-chat"
include(":app")
