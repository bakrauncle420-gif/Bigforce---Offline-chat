plugins {
    kotlin("multiplatform") version "1.9.10" apply false
}

buildscript {
    repositories {
        google()
        mavenCentral()
    }
}
