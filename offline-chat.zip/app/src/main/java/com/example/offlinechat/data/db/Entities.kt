package com.example.offlinechat.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey val id: String,
    val chatId: String,
    val senderId: String,
    val ciphertext: ByteArray,
    val timestamp: Long,
    val status: String?,
    val metadata: String?
)

@Entity(tableName = "attachments")
data class AttachmentEntity(
    @PrimaryKey val id: String,
    val messageId: String,
    val localPath: String?,
    val mimeType: String?,
    val size: Long?,
    val uploadedUrl: String?
)
