package com.example.offlinechat.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.Button
import androidx.compose.material.OutlinedTextField
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun ChatComposer(text: String, onTextChange: (String) -> Unit, onSend: (String) -> Unit) {
    Row(modifier = Modifier.fillMaxWidth().padding(4.dp)) {
        OutlinedTextField(value = text, onValueChange = onTextChange, modifier = Modifier.weight(1f))
        Spacer(modifier = Modifier.width(8.dp))
        Button(onClick = { onSend(text) }, modifier = Modifier.height(56.dp)) {
            Text("Send")
        }
    }
}
