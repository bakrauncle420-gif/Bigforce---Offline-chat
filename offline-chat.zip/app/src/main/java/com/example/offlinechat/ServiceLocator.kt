package com.example.offlinechat

import android.content.Context
import com.example.offlinechat.data.db.AppDatabase
import com.example.offlinechat.data.network.NetworkMonitor
import com.example.offlinechat.data.network.WebSocketClient

object ServiceLocator {
    private lateinit var appContext: Context
    lateinit var db: AppDatabase
    lateinit var networkMonitor: NetworkMonitor
    lateinit var wsClient: WebSocketClient

    fun init(context: Context) {
        appContext = context.applicationContext
        db = AppDatabase.create(appContext)
        networkMonitor = NetworkMonitor(appContext)
        wsClient = WebSocketClient(appContext)
        networkMonitor.start()
    }
}
