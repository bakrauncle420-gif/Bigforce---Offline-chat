package com.example.offlinechat.data.network

import android.content.Context
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.WebSocket
import okhttp3.WebSocketListener

class WebSocketClient(private val context: Context) {
    private val client = OkHttpClient()
    private var ws: WebSocket? = null

    fun connect(url: String = "wss://example.com/signaling") {
        val req = Request.Builder().url(url).build()
        ws = client.newWebSocket(req, object : WebSocketListener() {
        })
    }

    fun send(text: String) {
        ws?.send(text)
    }

    fun close() {
        ws?.close(1000, "bye")
    }

    fun isConnected(): Boolean = ws != null
}
