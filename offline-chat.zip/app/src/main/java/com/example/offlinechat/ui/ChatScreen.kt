package com.example.offlinechat.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.offlinechat.data.db.MessageEntity

@Composable
fun ChatScreen() {
    var messages by remember { mutableStateOf(sampleMessages()) }
    var composing by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().padding(8.dp)) {
        LazyColumn(modifier = Modifier.weight(1f)) {
            items(messages.size) { idx ->
                MessageRow(messages[idx])
            }
        }
        ChatComposer(text = composing, onTextChange = { composing = it }, onSend = {
            if (it.isNotBlank()) {
                messages = messages + MessageEntity(java.util.UUID.randomUUID().toString(), "chat1", "me", it.toByteArray(), System.currentTimeMillis(), "SENDING", null)
                composing = ""
            }
        })
    }
}

private fun sampleMessages(): List<MessageEntity> {
    return listOf(
        MessageEntity("1","chat1","alice","Hello".toByteArray(), System.currentTimeMillis() - 60000, "DELIVERED", null),
        MessageEntity("2","chat1","me","Hi Alice".toByteArray(), System.currentTimeMillis() - 30000, "SENT", null)
    )
}
