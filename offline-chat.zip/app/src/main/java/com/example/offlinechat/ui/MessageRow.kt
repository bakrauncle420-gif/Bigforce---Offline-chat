package com.example.offlinechat.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.Card
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.offlinechat.data.db.MessageEntity

@Composable
fun MessageRow(msg: MessageEntity) {
    val text = try { String(msg.ciphertext) } catch (e: Exception) { "<encrypted>" }
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Card(modifier = Modifier.padding(4.dp)) {
            Column(modifier = Modifier.padding(8.dp)) {
                Text(text = text)
                Text(text = msg.status ?: "", modifier = Modifier.padding(top = 4.dp))
            }
        }
    }
}
