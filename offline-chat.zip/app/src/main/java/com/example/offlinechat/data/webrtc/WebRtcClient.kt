package com.example.offlinechat.data.webrtc

import android.content.Context
import org.webrtc.*

class WebRtcClient(private val context: Context) {
    private var factory: PeerConnectionFactory? = null

    init {
        val options = PeerConnectionFactory.InitializationOptions.builder(context).createInitializationOptions()
        PeerConnectionFactory.initialize(options)
        factory = PeerConnectionFactory.builder().createPeerConnectionFactory()
    }

    fun createPeerConnection(iceServers: List<PeerConnection.IceServer>, observer: PeerConnection.Observer): PeerConnection? {
        val rtcConfig = PeerConnection.RTCConfiguration(iceServers)
        return factory?.createPeerConnection(rtcConfig, observer)
    }

    fun createAudioTrack(): AudioTrack? {
        val audioSource = factory?.createAudioSource(MediaConstraints())
        return factory?.createAudioTrack("ARDAMSa0", audioSource)
    }
}
