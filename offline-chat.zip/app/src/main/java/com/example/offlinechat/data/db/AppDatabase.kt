package com.example.offlinechat.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [MessageEntity::class, AttachmentEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun messageDao(): MessageDao

    companion object {
        @Volatile private var instance: AppDatabase? = null
        fun create(context: Context): AppDatabase {
            return instance ?: synchronized(this) {
                val inst = Room.databaseBuilder(context, AppDatabase::class.java, "offlinechat.db")
                    .build()
                instance = inst
                inst
            }
        }
    }
}
