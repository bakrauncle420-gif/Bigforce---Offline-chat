package com.example.offlinechat.data.sms

import android.content.Context
import android.telephony.SmsManager
import android.util.Log

class SmsManagerWrapper(private val context: Context) {
    private val smsManager: SmsManager = SmsManager.getDefault()

    fun sendEncryptedSms(destination: String, payload: ByteArray): Boolean {
        try {
            val text = android.util.Base64.encodeToString(payload, android.util.Base64.NO_WRAP)
            smsManager.sendTextMessage(destination, null, text, null, null)
            return true
        } catch (e: Exception) {
            Log.e("SmsManagerWrapper","send failed", e)
            return false
        }
    }
}
