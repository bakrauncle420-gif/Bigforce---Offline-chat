package com.example.offlinechat.work

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.offlinechat.ServiceLocator

class RetrySendWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val db = ServiceLocator.db
        val pending = db.messageDao().getByStatus("QUEUED")
        // TODO: attempt resend
        pending.forEach { msg ->
        }
        return Result.success()
    }
}
