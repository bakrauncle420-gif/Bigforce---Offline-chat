package com.example.offlinechat.data.encryption

object EncryptionManager {
    fun encrypt(plaintext: ByteArray, context: String): ByteArray {
        return plaintext.reversedArray()
    }

    fun decrypt(ciphertext: ByteArray, context: String): ByteArray {
        return ciphertext.reversedArray()
    }
}
