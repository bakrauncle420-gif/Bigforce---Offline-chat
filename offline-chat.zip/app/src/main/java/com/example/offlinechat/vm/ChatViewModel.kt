package com.example.offlinechat.vm

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.offlinechat.ServiceLocator
import com.example.offlinechat.data.db.MessageEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.util.*

class ChatViewModel : ViewModel() {
    private val _messages = MutableStateFlow<List<MessageEntity>>(emptyList())
    val messages: StateFlow<List<MessageEntity>> = _messages

    init {
        viewModelScope.launch {
            _messages.value = ServiceLocator.db.messageDao().getMessagesForChat("chat1")
        }
    }

    fun sendMessage(text: String) {
        viewModelScope.launch {
            val id = UUID.randomUUID().toString()
            val ciphertext = text.toByteArray()
            val msg = MessageEntity(id,"chat1","me",ciphertext,System.currentTimeMillis(),"SENDING",null)
            ServiceLocator.db.messageDao().insert(msg)
            _messages.value = _messages.value + msg
        }
    }
}
